

import React, { useState, useEffect } from "react";

const Demo = () => {
  const [name, setName] = useState("Loading");
  useEffect(() => {
    fetch("http://localhost:8080/api/home")
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setName(data.name);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  return (
    <>
      <div className="">
        <h1>{name}</h1>
      </div>
    </>
  );
};

export default Demo;
