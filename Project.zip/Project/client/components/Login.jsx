"use client";

import React from "react";
import { useState } from "react";

function Login() {
  var logo = "/img/logo.jpg";
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (event) => {
    let data = {userName, password};
    event.preventDefault();
    //check using API
    const response = await fetch("http://localhost:8080/api/login", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();
    if("statusCode" in result){
      alert(result.message);
    }else{
      alert(result.errorMsg);
    }


  };
  return (
    <div className="bg-gradient-to-b from-teal-300 to-gray-300 h-screen flex content-center">
      <div className="flex flex-col justify-center items-center m-auto bg-white w-auto p-8 rounded-xl">
        <img src={logo} alt="Image Not found" className="mt-5 w-auto h-14" />
        <form onSubmit={handleSubmit} className="flex flex-col items-center">
          <input
            type="text"
            id="userName"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            className="border-b border-gray-900 mt-5 px-1 text-lg"
            placeholder="Username"
            required
          />
          <input
            type={showPassword ? "text" : "password"}
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="border-b border-gray-900 mt-5 px-1 text-lg"
            placeholder="Password"
            required
          />
          <label htmlFor="showPassword" className="text-lg">
            <input
              type="checkbox"
              name="showPassword"
              id="showPassword"
              value={showPassword}
              onChange={(e) => setShowPassword((prev) => !prev)}
              className="mt-5 mr-5"
            />
             Show Password
          </label>
          <button
            type="submit"
            id="sumbitBtn"
            className="border border-teal-600 bg-teal-500 rounded-xl mt-5 px-7"
          >
            Login
          </button>
          <h4 className="mt-2">
            Need an Account? <a href="/signup">Signup</a>
          </h4>
        </form>
      </div>
    </div>
  );
}

export default Login;
