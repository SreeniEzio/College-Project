import Signup from "@/components/Signup" 

export default function SignUp() {
    return (
      <>
        <div className="">
          <Signup />
        </div>
      </>
    );
  }