"use client";
import React from "react";
import { useState } from "react";


function Signup() {
  var registerImg = "/img/logo.jpg";
  const [name, setName] = useState("");
  const [age, setAge] = useState(null);
  const [userId, setUserId] = useState();
  const [password, setPassword] = useState("");

  const handleSubmit = async (event) => {
    let data = {name, age, userId, password};
    event.preventDefault();
    //check using API
    const response = await fetch("http://localhost:8080/api/signup", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const result = await response.json();
    if("statusCode" in result){
      alert(result.message);
    }else{
      alert(result.errorMsg);
    }

  };
  return (
    <div className="bg-gradient-to-b from-teal-300 to-gray-300 h-screen flex content-center">
      <div className="flex flex-col justify-center items-center m-auto bg-white w-auto p-8 rounded-xl">
        <div className="flex">
          <img
            src={registerImg}
            alt="Image Not found"
            className="m-3 w-auto h-14"
          />
          <h4 className="m-3 mt-5 text-center">REGISTER USER</h4>
        </div>
        <form onSubmit={handleSubmit} className="flex flex-col">
          <div className="grid grid-cols-2">
            <label htmlFor="name" className="text-left p-3">
              NAME
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="border border-gray-900 m-2 px-1 rounded-md bg-gray-300"
            />
          </div>
          <div className="grid grid-cols-2">
            <label htmlFor="age" className="text-left p-3">
              AGE
            </label>
            <input
              type="number"
              id="age"
              name="age"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className="border border-gray-900 m-2 px-1 w-14 rounded-md bg-gray-300"
            />
          </div>

          <div className="grid grid-cols-2">
            <label htmlFor="userid" className="text-left p-3">
              USER ID
            </label>
            <input
              type="text"
              id="userid"
              name="userid"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              className="border border-gray-900 m-2 px-1 rounded-md bg-gray-300"
            />
          </div>
          <div className="grid grid-cols-2">
            <label htmlFor="password" className="text-left p-3">
              PASSWORD
            </label>
            <input
              type="password"
              id="password"
              value={password}
              name="password"
              onChange={(e) => setPassword(e.target.value)}
              className="border border-gray-900 m-2 px-1 rounded-md bg-gray-300"
            />
          </div>

          <div className="grid grid-cols-2">
            <label htmlFor="uploadPhoto" className="text-left p-3">
              UPLOAD PHOTO
            </label>
            <input
              type="file"
              id="uploadPhoto"
              onChange={(e) => setPhoto(e.target.value)}
              className="border border-gray-900 m-2 px-1 rounded-md bg-gray-300"
              placeholder=""
            />
          </div>

          <div className="flex flex-col justify-center items-center">
            <button
              type="submit"
              id="sumbitBtn"
              className="border border-teal-600 bg-teal-500 rounded-xl mt-3 px-7 w-fit "
            >
              REGISTER
            </button>
            <h4 className="mt-3">
              Already have account? <a href="/">Login</a>
            </h4>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Signup;
